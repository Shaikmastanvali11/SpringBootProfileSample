package com.springboot.profiles.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/rest")
public class HelloworldCtrl {

	private static Logger LOGGER = LoggerFactory.getLogger(HelloworldCtrl.class);

	@Value(value = "${spring.message}")
	private String message;
	@Autowired
	private ApplicationContext context;

	@GetMapping(value = "/hello")
	public String welcome() {
		LOGGER.info("Returning the response.");		
		LOGGER.info(message);
		initiateAppShutdown(0);
		return message; 
	}

	public void initiateAppShutdown(int returnCode) {
		LOGGER.info("shutting down the application");
		SpringApplication.exit(context, () -> returnCode);
	}
    
}
